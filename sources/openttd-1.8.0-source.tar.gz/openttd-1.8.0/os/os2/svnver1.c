/* rev.c part #1 for OS/2 - ensure no newline at end of file! */

const char _openttd_revision[] = "r