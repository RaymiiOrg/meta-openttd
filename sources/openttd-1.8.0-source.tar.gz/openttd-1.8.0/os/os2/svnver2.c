";
const int _revision_number = 0;

/* rev.c part 2 for OS/2 - ensure no newline at start of file! */